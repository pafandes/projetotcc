package br.edu.ifgoiano.configuration;

import org.springframework.context.annotation.Configuration;

@Configuration
public class SecurityConfig {
        
         
}
